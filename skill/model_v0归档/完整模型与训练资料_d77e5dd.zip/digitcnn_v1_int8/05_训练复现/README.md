# B 的训练复现档案

A/C 不需要运行此目录，日常预测使用 `02_运行代码`。这里保留模型的训练来源、量化推导与 checkpoint，便于 B 调参和解释设计。

## 先读代码导读，再运行实验

- [代码导读](代码导读.md)：每个脚本的职责与 CNN 结构中文讲解。
- [实验工程](实验工程/README.md)：复现命令和环境要求。
- [历史设计说明](历史设计说明/README.md)：原浮点/定点推导记录。

实验工程内部的 runs 布局保持原样，避免破坏 checkpoint、数据索引与历史参考之间的联系。`model.py` 的字节哈希被 checkpoint 记录，因此保留其原字节，中文讲解放在代码导读；其他实验脚本已补中文入口/函数注释。

数值来源是本团队此前训练和量化的 DigitCNN。MNIST 经 torchvision 获取。代码由 B 在 AI 辅助下生成、执行和检查，依赖 PyTorch/torchvision、NumPy、Pillow、matplotlib、Jupyter；各依赖许可按其分发内容。未移植整套 FPGA CNN RTL，此包不包含 FPGA 加速器。
