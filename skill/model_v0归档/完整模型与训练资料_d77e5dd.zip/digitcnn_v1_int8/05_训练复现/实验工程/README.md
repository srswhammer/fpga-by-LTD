# 实验工程（在独立副本运行）

先将整个交接包复制为实验副本，再进入此目录。很多历史脚本固定写 runs/baseline_v1；在交接原件执行可能覆盖旧实验记录。

## 环境和数据

使用独立电脑 Python 环境安装 PyTorch、torchvision、NumPy、Pillow、matplotlib。requirements.lock.txt 是原电脑版本记录，不是 PYNQ 板上安装清单。

完整 MNIST 不在包内。首次在本目录执行：

```python
from torchvision.datasets import MNIST
MNIST("data", train=True, download=True)
MNIST("data", train=False, download=True)
```

## 复核已有实验

```text
python evaluate_baseline.py
python validate_software_prediction.py
python verify_float_reference.py
python design_fixed_point_candidate.py
python verify_fixed_point_candidate.py
python evaluate_integer_v1.py
python verify_integer_v1.py
```

`export_float_reference.py` 用于重新导出浮点参考，已有参考复核不必重导。

新训练可以执行 `python train_baseline.py --run-dir runs/retrain_v1`。其他历史脚本仍默认 baseline_v1，不能自动转向新训练目录；实验新模型时应配套修改路径并重新评估。

整数发布实验会写 `runs/digitcnn_v1_int8`，不会自动覆盖交接包的 `03_模型数据`。迁入新模型必须重新确认位宽、精度、逐层答案和硬件接口。

原训练：55k/5k 划分、seed=42、Adam、lr=0.001、batch=64、5 epochs，按验证集选择 checkpoint。跨环境浮点结果可能略有差异，固定整数计算应一致。
