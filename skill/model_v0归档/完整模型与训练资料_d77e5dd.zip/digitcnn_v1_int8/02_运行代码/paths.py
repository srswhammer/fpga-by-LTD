"""交接包的统一路径表。目录改名时先检查这里以及发布配置。"""
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
CODE_DIR = PACKAGE_ROOT / "02_运行代码"
MODEL_DIR = PACKAGE_ROOT / "03_模型数据"
PARAMETER_DIR = MODEL_DIR / "参数"
REFERENCE_DIR = MODEL_DIR / "逐层标准答案"
EVALUATION_DIR = PACKAGE_ROOT / "04_验证与评估" / "精度结果"
EXAMPLE_DIR = CODE_DIR / "示例图片"
MANIFEST_PATH = PACKAGE_ROOT / "04_验证与评估" / "整包校验清单.json"
# 新运行产生的报告不是发布证据，存入被 Git 和打包工具忽略的目录。
WORK_DIR = PACKAGE_ROOT / "work"
