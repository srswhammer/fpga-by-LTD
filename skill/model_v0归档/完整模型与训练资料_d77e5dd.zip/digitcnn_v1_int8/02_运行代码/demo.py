"""软件演示：加载已有整数参数，无需训练、下载数据或连接开发板。"""
from pathlib import Path
import argparse
import numpy as np
from integer_inference import IntegerDigitCNN
from preprocess import preprocess_digit_image

from paths import REFERENCE_DIR

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--image', type=Path)
    args = parser.parse_args()
    model = IntegerDigitCNN.from_directory()
    # 指定图片先做预处理；未指定时使用已导出的十张固定输入。
    if args.image:
        inputs = preprocess_digit_image(args.image).normalized_uint8
    else:
        inputs = np.load(REFERENCE_DIR/'fixed_inputs_uint8.npy', allow_pickle=False)
    result = model.forward(inputs)
    print('预测数字：', result.predictions.tolist())
    print('十类整数分数：', result.scores_int32.tolist())

if __name__ == '__main__':
    main()
