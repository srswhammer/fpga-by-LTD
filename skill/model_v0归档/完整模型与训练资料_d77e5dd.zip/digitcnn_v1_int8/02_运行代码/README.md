# 运行代码：A/C 日常使用

首选在包根目录运行 `python 启动.py 演示` 或 `python 启动.py 校验`，无需自己寻找脚本顺序。

| 阅读顺序 | 文件 | 职责 |
|---|---|---|
| 1 | [演示.ipynb](演示.ipynb) | 中文步骤、图片与结果展示 |
| 2 | [demo.py](demo.py) | 如何串联图片处理和推理 |
| 3 | [preprocess.py](preprocess.py) | 图片变成模型输入，各阶段有中文说明 |
| 4 | [integer_inference.py](integer_inference.py) | 六个计算阶段的中文注释 |
| 查询 | [paths.py](paths.py) | 数据所在目录的统一定义 |
| 检查 | [verify_package.py](verify_package.py) | 完整性，只有标准库依赖 |
| 检查 | [verify_release.py](verify_release.py) | 发布数据及逐层一致性 |
| 检查 | [verify_packaging.py](verify_packaging.py) | 独立标量实现与参数解码对比 |

[返回总地图](../00_阅读地图.md)。运行新报告只写到 `work/`。
