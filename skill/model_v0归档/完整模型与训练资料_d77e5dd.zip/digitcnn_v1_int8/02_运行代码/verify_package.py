"""整包字节完整性检查。只依赖 Python 标准库，不加载模型。"""
import hashlib
import json
from paths import PACKAGE_ROOT, MANIFEST_PATH

def main():
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    for name, expected in manifest["files"].items():
        path = (PACKAGE_ROOT / name).resolve()
        # 清单只允许引用包内文件，不能沿相对路径跳到包外。
        if not path.is_relative_to(PACKAGE_ROOT) or not path.is_file():
            raise ValueError("清单路径无效或文件缺失：" + name)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError("文件校验失败：" + name)
    print("整包校验通过，文件数：", len(manifest["files"]))

if __name__ == "__main__":
    main()
