"""统一入口：python 启动.py 演示 / 校验 / 图片 --image 图片路径。"""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CODE = ROOT / "02_运行代码"

def main():
    parser = argparse.ArgumentParser(description="手写数字模型交接包：软件运行与验证")
    parser.add_argument("操作", choices=["演示", "校验", "图片"])
    parser.add_argument("--image", type=Path, help="单数字图片的路径，仅用于图片操作")
    args = parser.parse_args()
    if args.操作 == "图片" and args.image is None:
        parser.error("图片操作需要 --image 指定图片")
    if args.操作 != "图片" and args.image is not None:
        parser.error("--image 仅用于图片操作")
    if args.操作 == "校验":
        scripts = ["verify_package.py", "verify_release.py", "verify_packaging.py"]
    else:
        scripts = ["demo.py"]
    for script in scripts:
        # 使用当前 Python 环境；子进程失败立即停止，不能把失败当作通过。
        command = [sys.executable, str(CODE / script)]
        if args.操作 == "图片":
            command += ["--image", str(args.image.resolve())]
        subprocess.run(command, check=True)

if __name__ == "__main__":
    main()
