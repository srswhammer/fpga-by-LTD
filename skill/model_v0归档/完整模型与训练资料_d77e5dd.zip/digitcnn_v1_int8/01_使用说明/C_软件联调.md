# C：先让软件结果可复现，再替换为硬件调用

## 先跑通入口

按 [运行说明](运行与环境.md) 执行演示和图片预测。更方便的逐格入口是 [演示 Notebook](../02_运行代码/演示.ipynb)。

进入 `02_运行代码` 后，可在 Python 中调用：

```python
from preprocess import preprocess_digit_image
from integer_inference import IntegerDigitCNN

model = IntegerDigitCNN.from_directory()  # 程序开始只加载一次
prepared = preprocess_digit_image("示例图片/camera_like_00_label_1.png")
pixels = prepared.normalized_uint8       # 形状 [28,28]，uint8
result = model.forward(pixels)
print(int(result.predictions[0]))
print(result.scores_int32[0])             # 十个分数，不是概率
```

这里使用 CPU 计算。A 的硬件完成后，保留同一份 `pixels`，将计算调用替换为经验证的 Overlay/DMA 调用；同时留 CPU 参考作为联调对照。

## 摄像头数据如何接入

- 先提取只含一个完整数字的 ROI，背景简单、数字不贴边。
- 支持路径、PIL、灰度或 RGB/RGBA 数组；OpenCV 的 BGR 帧先转 RGB。
- 预处理已经标准化的 28×28 图时不要重复做其他归一化。
- 空白或低对比度会报 ValueError；界面显示“未找到清晰数字”，不能沿用上一帧标签。
- 不具备多数字检测，也不能保证拒绝所有非数字物体。

## 与 A 商定后再实现

输入缓冲区、每拍字节顺序、DMA 长度、TLAST/TKEEP、寄存器偏移、启动/完成状态、超时、缓存同步。当前原始输入为 784 字节，输出十个 int32 为 40 字节；总线打包及驱动尚未定稿。

先每类收集约 10 张真实有标签 ROI，保存原图、28×28 图、预测与光照情况。本包 94.10% 是合成拍照图结果，不能写成 OV5640 实拍成绩。
