# 参数：同一套权重，按使用场景选择格式

| 形式 | 用什么读取 | 谁用 |
|---|---|---|
| model_parameters_int.npz | NumPy 一次读取四个具名数组 | CPU 整数模型默认使用 |
| 四个 .npy | NumPy 分别读取单个数组 | 调试、检查或转换 |
| 四个 .mem | Verilog $readmemh，逐行十六进制补码 | A 仿真/初始化 |
| model_parameters_v1.bin | 按偏移读取无头字节 | A 运行时加载方案 |
| binary_layout.json | 文本/JSON | 解释 BIN 偏移、长度与端序 |

`conv` 是卷积，`fc` 是全连接；`weight` 是权重，`bias` 是偏置。权重 int8、偏置 int32。它们表示同一个模型，不需要全部加载进硬件。

NPY/NPZ 有文件头，不能把整个文件直接当原始数据发送。MEM 不是 AXI 的多像素打包格式。完整规格见 [数值与接口](../../01_使用说明/数值与接口.md)。
