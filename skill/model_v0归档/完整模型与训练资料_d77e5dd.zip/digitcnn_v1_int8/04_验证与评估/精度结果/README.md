# 精度结果怎么看

组长/B 先看 [summary.json](summary.json) 和 [精度对比图](accuracy_comparison.png)。

| 文件前缀 | 数据来源 |
|---|---|
| validation | 固定验证集 5000 张，用于验证 |
| official_test | 官方测试集 10000 张，用于报告 |
| synthetic_camera_like | 合成拍照风格 1000 张，不是 OV5640 实拍 |

| 文件后缀 | 含义 |
|---|---|
| confusion_int8.csv / .png | 整数模型混淆矩阵，行是真值、列是预测 |
| per_class_accuracy.csv | 每个数字的分类准确率 |
| predictions.npz | 逐样本标签、浮点/整数预测及分数，用于复核统计 |
| quantization_disagreements.png | 量化前后预测不同的图片示例 |

这些文件不用逐个执行。A/C 初期只需知道当前精度和验证边界。
