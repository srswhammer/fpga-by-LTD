# 整理前的验收记录

- verification.json：发布参数格式、逐层结果、精度统计检查。
- packaging_checks.json：14 张输入的独立标量检查、BIN/MEM 解码检查及当时环境。
- preprocessing_parity.json：原含 PyTorch 版与便携版在 22 张图片上的预处理一致性。

这些是原始记录，不是本次重新运行生成的报告。本次复核在上一级目录；开发板验收仍未完成。
